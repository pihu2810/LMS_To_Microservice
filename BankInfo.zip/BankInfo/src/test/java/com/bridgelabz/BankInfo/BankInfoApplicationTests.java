package com.bridgelabz.BankInfo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankInfoApplicationTests {

	@Test
	void contextLoads() {
	}

}
