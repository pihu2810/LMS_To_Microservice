package com.bridgelabz.CandidateAPIgateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CandidateApIgatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
