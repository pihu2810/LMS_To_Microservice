package com.bridgelabz.CandidateEureka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CandidateEurekaApplicationTests {

	@Test
	void contextLoads() {
	}

}
