package com.bridgelabz.Qualification;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QualificationApplication {

	public static void main(String[] args) {
		SpringApplication.run(QualificationApplication.class, args);
	}

}
